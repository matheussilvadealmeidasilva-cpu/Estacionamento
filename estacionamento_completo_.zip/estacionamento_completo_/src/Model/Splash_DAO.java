/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import View.Login_GUI;
import View.Splash_GUI;
import static View.Splash_GUI.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingUtilities;


/**
 *
 * @author alunos
 */
public class Splash_DAO {
    
    public static void splash_screen(Splash_GUI splash){
        new Thread() {
        public void run() {

            for (int i = 0; i < 101; i++) {
                try {
                    sleep(60);

                    progresso.setValue(i);

                    if (progresso.getValue() == 10) {
                        mensagem.setText("Fazendo a conexao com o banco de dados");
                        // driver_conexao.carregardriver();
                        sleep(2000);

                    } else if (progresso.getValue() <= 30) {
                        mensagem.setText("Carregando o sistema");
                        sleep(100);

                    } else if (progresso.getValue() <= 99) {
                        mensagem.setText("Carregamento quase completo");

                    } else {
                        mensagem.setText("Carregamento completo. Seu programa sera iniciado.");
                        sleep(3000);

                        // Executa abertura do Login_GUI na EDT
                        SwingUtilities.invokeLater(() -> {
                            new Login_GUI().setVisible(true);
                            splash.dispose();// Fecha o Splash_GUI
                        });
                    }

                } catch (InterruptedException ex) {
                    Logger.getLogger(Splash_GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }.start();
}
    }

