/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import View.Login_GUI;
import static View.Login_GUI.*;
import View.Tela_inicial_GUI;
import static View.Tela_inicial_GUI.*;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import javax.swing.JOptionPane;

// IMPORTAÇÕES ESPECÍFICAS PARA O PDF (Sem conflitos)
import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfWriter;

/**
 *
 * @author User
 */
public class Funcoes_DAO {

    static String placa, modelo, marca, entrada, saida, data, status;

    static String url = "jdbc:mysql://localhost:3307/estacionamento"; // endereço do BD
    static String username = "root";        //nome de um usuário de seu BD
    static String password = "";  // senha do BD

    public static void login(Login_GUI login) {
        //--Inicio
        String usuario = usuario_txt.getText();
        String senha = senha_txt.getText();

        if (usuario.equals("admin") && senha.equals("admin")) {
            JOptionPane.showMessageDialog(null, "Login realizado com sucesso");
            new Tela_inicial_GUI().setVisible(true);
            login.dispose();

        } else if (usuario.equals("funcionario") && senha.equals("func")) {
            JOptionPane.showMessageDialog(null, "Login realizado com sucesso");
            new Tela_inicial_GUI().setVisible(true);
            painel_guias.remove(fluxo_caixa);
            login.dispose();

        } else {

            JOptionPane.showMessageDialog(null, " Login ou Senha incorreta");
            usuario_txt.setText("");
            senha_txt.setText("");
        }

        //--Fim
    }

   public static void cadastrar() {
    // 1. Coleta de dados da interface
    String placa = placa_txt.getText().trim().toUpperCase(); 
    String modelo = modelo_txt.getText().trim();
    String marca = marca_txt.getText().trim();
    
    String dataAtual = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
    String horaEntrada = new SimpleDateFormat("HH:mm").format(new Date());

    String sqlVeiculos = "INSERT INTO veiculos (placa, marca, modelo, horario_entrada, horario_saida, data, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
   
    String sqlParados = "INSERT INTO parados (placa, marca, modelo) VALUES (?, ?, ?)";

    Controller.conexão_BD.carregaDriver();

    try (Connection con = DriverManager.getConnection(url, username, password)) {
        
        con.setAutoCommit(false);

        try (PreparedStatement stmtV = con.prepareStatement(sqlVeiculos);
             PreparedStatement stmtP = con.prepareStatement(sqlParados)) {

            stmtV.setString(1, placa);
            stmtV.setString(2, marca);
            stmtV.setString(3, modelo);
            stmtV.setString(4, horaEntrada);
            stmtV.setString(5, "---"); 
            stmtV.setString(6, dataAtual);
            stmtV.setString(7, "estacionado"); 
            stmtV.executeUpdate();

            stmtP.setString(1, placa);
            stmtP.setString(2, marca);
            stmtP.setString(3, modelo);
            stmtP.executeUpdate();

            con.commit();
            JOptionPane.showMessageDialog(null, "Veículo cadastrado com sucesso!");

            // CHAMA O PROCESSO DO PDF AQUI
            gerartickt();
            
            limpar();

        } catch (SQLException ex) {
            con.rollback(); // Se der erro em um, cancela tudo para não desisncronizar
            JOptionPane.showMessageDialog(null, "Erro ao gravar dados: " + ex.getMessage());
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro de conexão!");
    }
    
        placa_txt.setText("");
        modelo_txt.setText("");
        marca_txt.setText("");       
}

      public static void pesquisar() {
    String placaBusca = pesquisa.getText().trim();

    if (placaBusca.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Digite uma placa para pesquisar.");
        return;
    }

    String sql = "SELECT modelo, marca, status FROM veiculos WHERE placa = ?";

    try (Connection con = DriverManager.getConnection(url, username, password);
         PreparedStatement stm = con.prepareStatement(sql)) {
        
        stm.setString(1, placaBusca);
        
        try (ResultSet rs = stm.executeQuery()) {
            if (rs.next()) {
                String modelo = rs.getString("modelo");
                String marca = rs.getString("marca");
                String status = rs.getString("status");

                mostra_modelo_txt.setText(modelo);
                mostra_marca_txt.setText(marca);
                status_txt.setText(status.toUpperCase());

            } else {
                JOptionPane.showMessageDialog(null, "Placa não encontrada.");
                limpar();
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro ao pesquisar: " + ex.getMessage());
    }

        // ---> Fim
    }
      
      public static void atualizar() {
    String novoModelo = mostra_modelo_txt.getText();
    String novaMarca = mostra_marca_txt.getText();
    String placaBusca = pesquisa.getText().trim();

    if (placaBusca.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Pesquise uma placa antes de atualizar.");
        return;
    }

    Controller.conexão_BD.carregaDriver();

    String sqlParados = "UPDATE parados SET modelo = ?, marca = ? WHERE placa = ?";
    String sqlVeiculos = "UPDATE veiculos SET modelo = ?, marca = ? WHERE placa = ?";

    try (Connection con = DriverManager.getConnection(url, username, password)) {
        
        con.setAutoCommit(false);

        try (PreparedStatement stmParados = con.prepareStatement(sqlParados);
             PreparedStatement stmVeiculos = con.prepareStatement(sqlVeiculos)) {

            stmParados.setString(1, novoModelo);
            stmParados.setString(2, novaMarca);
            stmParados.setString(3, placaBusca);
            stmParados.executeUpdate();

            stmVeiculos.setString(1, novoModelo);
            stmVeiculos.setString(2, novaMarca);
            stmVeiculos.setString(3, placaBusca);
            stmVeiculos.executeUpdate();

            con.commit();

            JOptionPane.showMessageDialog(null, "Dados updated com sucesso!");
            
            pesquisa.setText("");
            mostra_modelo_txt.setText("");
            mostra_marca_txt.setText("");
            status_txt.setText("");

        } catch (SQLException ex) {
            con.rollback(); 
            JOptionPane.showMessageDialog(null, "Erro ao atualizar os dados!");
            ex.printStackTrace();
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro de conexão com o servidor");
    }

        // ---> Fim
    }
      
           public static void limpar() {
        pesquisa.setText("");
        pesquisa2.setText("");
        mostra_modelo_txt.setText("");
        mostra_marca_txt.setText("");
        status_txt.setText("");
    }
               
  public static void pesquisar2() {
    String placaBusca = pesquisa2.getText().trim().toUpperCase();

    if (placaBusca.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Digite a placa no campo de saída.");
        return;
    }

    Controller.conexão_BD.carregaDriver();

    String sql = "SELECT modelo, marca, horario_entrada, horario_saida FROM veiculos WHERE placa = ? AND status = 'estacionado'";

    try (Connection con = DriverManager.getConnection(url, username, password);
         PreparedStatement stm = con.prepareStatement(sql)) {

        stm.setString(1, placaBusca);

        try (ResultSet rs = stm.executeQuery()) {
            if (rs.next()) {
                String hEntrada = rs.getString("horario_entrada");
                
                modelo2.setText(rs.getString("modelo"));
                marca2.setText(rs.getString("marca"));
                entrada1.setText(hEntrada);
                entrada2.setText(hEntrada);
               
                String hSaidaAtual = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
                saida1.setText(hSaidaAtual); 

                DateTimeFormatter formato = DateTimeFormatter.ofPattern("HH:mm");
                LocalTime horaEntrada = LocalTime.parse(hEntrada, formato);
                LocalTime horaSaida = LocalTime.parse(hSaidaAtual, formato);

                long minutes = ChronoUnit.MINUTES.between(horaEntrada, horaSaida);
                if (minutes < 0) minutes += 1440; 

                double valorTotal = (minutes / 60.0) * 15.0;

                valor_txt.setText(String.format("%.2f", valorTotal));

            } else {
                JOptionPane.showMessageDialog(null, "Veículo não encontrado ou já saiu!");
                limpar();
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro ao conectar: " + ex.getMessage());
    }

        // ---> Fim
    }
  

    
   public static void confirmarPagamento() {
       // ---> Inicio
       
    String placa = pesquisa2.getText().trim().toUpperCase();
    String mod = modelo2.getText();
    String hEntrada = entrada1.getText(); 
    String hSaida = saida1.getText();   
    
    String valorTexto = valor_txt.getText().replace(",", ".");
    double valor1 = Double.valueOf(valorTexto);
    
    String forma = forma_pagamento.getSelectedItem().toString();

    if (placa.isEmpty() || valorTexto.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Erro: Pesquise a placa antes de pagar!");
        return;
    }

    String sqlFin = "INSERT INTO entradas (cliente, descricao, data, forma_pagamento, valor) VALUES (?, ?, ?, ?, ?)";
    String sqlUpd = "UPDATE veiculos SET status = 'Fora do estacionamento', horario_saida = ? WHERE placa = ?";
    String sqlDel = "DELETE FROM parados WHERE placa = ?";
    
   
    String sqlSaldo = "UPDATE saldo SET saldo = saldo + ?, entrando = entrando + ?";

    String dataAtual = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date());

    Controller.conexão_BD.carregaDriver();

    try (Connection con = DriverManager.getConnection(url, username, password)) {
        con.setAutoCommit(false); 

        try (PreparedStatement stmFin = con.prepareStatement(sqlFin);
             PreparedStatement stmUpd = con.prepareStatement(sqlUpd);
             PreparedStatement stmDel = con.prepareStatement(sqlDel);
             PreparedStatement stmSaldo = con.prepareStatement(sqlSaldo)) {

            
            stmFin.setString(1, placa); 
            stmFin.setString(2, "Saída: " + mod + " (" + hEntrada + "-" + hSaida + ")");
            stmFin.setString(3, dataAtual);
            stmFin.setString(4, forma); 
            stmFin.setFloat(5, Float.parseFloat(valorTexto)); 
            stmFin.executeUpdate();

            
            stmUpd.setString(1, hSaida);
            stmUpd.setString(2, placa);
            stmUpd.executeUpdate();

           
            stmDel.setString(1, placa);
            stmDel.executeUpdate();
            
            
            stmSaldo.setDouble(1, valor1);
            stmSaldo.setDouble(2, valor1);
            stmSaldo.executeUpdate();

            con.commit(); 
            JOptionPane.showMessageDialog(null, "Pagamento de R$ " + valorTexto + " registrado!\nVeículo liberado.");
            
            
            buscarSaldoInicial();

            
            pesquisa2.setText("");
            modelo2.setText("");
            marca2.setText("");
            entrada1.setText("");
            entrada2.setText("");
            saida1.setText("");
            valor_txt.setText("");

        } catch (SQLException ex) {
            con.rollback(); 
            JOptionPane.showMessageDialog(null, "Erro ao processar: " + ex.getMessage());
        }
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Erro Geral: " + ex.getMessage());
    }
    
    refresh();
    
    // --->Fim
    
   }
  
    public static void saidas() {
        
        //---> Inicio
        
    String descrição = descrição_txt.getText().trim().toUpperCase(); 
    String valor = valor2_txt.getText().trim();
    String forma = (String) forma_txt.getSelectedItem();
    double valor1 = Double.valueOf(valor);
    
    String dataAtual = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
    String horaEntrada = new SimpleDateFormat("HH:mm").format(new Date());

    String sqlsaidas = "INSERT INTO saidas (descricao, forma_pagamento, valor, data, horario) VALUES (?, ?, ?, ?, ?)";
    
    
    String sqlSaldo = "UPDATE saldo SET saldo = saldo - ?, saindo = saindo + ?";

    Controller.conexão_BD.carregaDriver();

    try (Connection con = DriverManager.getConnection(url, username, password)) {
        
        con.setAutoCommit(false);

        try (PreparedStatement stmtV = con.prepareStatement(sqlsaidas);
             PreparedStatement stmtS = con.prepareStatement(sqlSaldo)) {

            stmtV.setString(1, descrição);
            stmtV.setString(2, forma);
            stmtV.setString(3, valor);
            stmtV.setString(4, dataAtual);
            stmtV.setString(5, horaEntrada); 
            stmtV.executeUpdate();
            
            
            stmtS.setDouble(1, valor1);
            stmtS.setDouble(2, valor1);
            stmtS.executeUpdate();
            
            con.commit();
            JOptionPane.showMessageDialog(null, "Conta registrada!");
            
            
            buscarSaldoInicial();
            
            descrição_txt.setText("");
            valor2_txt.setText("");

            limpar();

        } catch (SQLException ex) {
            con.rollback(); 
            JOptionPane.showMessageDialog(null, "Erro ao gravar dados: " + ex.getMessage());
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro de conexão!");
    }
    
        placa_txt.setText("");
        modelo_txt.setText("");
        marca_txt.setText("");
   
    Cap();
    
    //--->Fim
}

        public static void refresh() {
        try {
            Connection conn;
            conn = (Connection) DriverManager.getConnection(url, username, password);
            Controller.conexão_BD.carregaDriver();

            String sql = "SELECT * FROM entradas;";
            PreparedStatement pst = (PreparedStatement) conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            tabela_entradas.setModel(estacionamento(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static void Cap() {
        try {
            Connection conn;
            conn = (Connection) DriverManager.getConnection(url, username, password);
            Controller.conexão_BD.carregaDriver();

            String sql = "SELECT * FROM saidas;";
            PreparedStatement pst = (PreparedStatement) conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            tabela_saidas.setModel(estacionamento(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public static void gerartickt() {
        
        //--->Inico
        
    String placa_v = placa_txt.getText().trim().toUpperCase();
    String modelo_v = modelo_txt.getText().trim();
    String marca_v = marca_txt.getText().trim();
    String dataAtual = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
    String horaEntrada = new SimpleDateFormat("HH:mm").format(new Date());

    Document doc = null;
    OutputStream os = null;

    // Ajustei para salvar o arquivo dinamicamente com a placa na pasta certa
    String caminho = "C:\\Users\\Alunos\\Documents\\Estacionamento\\ticket_" + placa_v + ".pdf";

    try {
        doc = new Document(PageSize.A4, 72, 72, 72, 72);
        os = new FileOutputStream(caminho);
        PdfWriter.getInstance(doc, os);
        
        // Fontes explícitas do iText
        com.itextpdf.text.Font fTitle = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.COURIER, 16, com.itextpdf.text.Font.BOLD);
        com.itextpdf.text.Font fBody = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.COURIER, 12, com.itextpdf.text.Font.NORMAL);
        
        doc.open();

        try {
            Image img = Image.getInstance("C:\\Users\\User\\Downloads\\logo_estacionamento.png");
            img.setAlignment(Paragraph.ALIGN_CENTER);
            doc.add(img);
        } catch (Exception e) {
            System.out.println("Logo ignorada.");
        }
        
        // Montagem do corpo do Ticket impresso no PDF
        Paragraph pa1 = new Paragraph("TICKET DE ENTRADA", fTitle);
        pa1.setAlignment(Paragraph.ALIGN_CENTER);
        pa1.setSpacingAfter(15);
        doc.add(pa1);
        
        Paragraph pa2 = new Paragraph(
            "------------------------------------------\n" +
            "PLACA:    " + placa_v + "\n" +
            "MARCA:    " + marca_v + "\n" +
            "MODELO:   " + modelo_v + "\n" +
            "DATA:     " + dataAtual + "\n" +
            "ENTRADA:  " + horaEntrada + "\n" +
            "------------------------------------------\n\n" +
            "Guarde este ticket para validação da saída.\n" +
            "Valor da hora corrente: R$ 15,00", fBody
        );
        doc.add(pa2);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Erro ao gerar PDF: " + e.getMessage());
    } finally {
        if (doc != null) {
            doc.close();
        }
        try {
            if (os != null) {
                os.close();
            }
        } catch (Exception e) {
            System.out.println("Erro ao fechar arquivo.");
        }
    }
    
    try {
        // Abre perfeitamente o mesmo arquivo gerado baseado na placa digitada
        Desktop.getDesktop().open(new File(caminho));
    } catch (Exception e) {
        System.out.println("Erro ao abrir o PDF.");
    }
    
    //---> Fim
    
 }
    
    public static void buscarSaldoInicial() {
        
        //--->Inicio
        
    String sql = "SELECT saldo, saindo, entrando FROM saldo LIMIT 1";
    
    try (Connection con = DriverManager.getConnection(url, username, password);
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {
         
        if (rs.next()) {
            double saldoSalvo = rs.getDouble("saldo");
            double saindoSalvo = rs.getDouble("saindo");
            double entrandoSalvo = rs.getDouble("entrando");
            
            // Preenche as suas três JLabels formatadas com duas casas decimais (R$ 0,00)
            saldo_txt.setText(String.format("%.2f", saldoSalvo));
            saindo_txt.setText(String.format("%.2f", saindoSalvo));
            entrando_txt.setText(String.format("%.2f", entrandoSalvo));
        }
    } catch (SQLException e) {
        System.out.println("Erro ao carregar dados do saldo inicial: " + e.getMessage());
    }
    
    //--->Fim
    
}
}