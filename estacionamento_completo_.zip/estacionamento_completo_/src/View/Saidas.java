/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author alunos
 */
@Entity
@Table(name = "saidas", catalog = "estacionamento", schema = "")
@NamedQueries({
    @NamedQuery(name = "Saidas.findAll", query = "SELECT s FROM Saidas s")
    , @NamedQuery(name = "Saidas.findByCodigo", query = "SELECT s FROM Saidas s WHERE s.codigo = :codigo")
    , @NamedQuery(name = "Saidas.findByDescricao", query = "SELECT s FROM Saidas s WHERE s.descricao = :descricao")
    , @NamedQuery(name = "Saidas.findByFormaPagamento", query = "SELECT s FROM Saidas s WHERE s.formaPagamento = :formaPagamento")
    , @NamedQuery(name = "Saidas.findByValor", query = "SELECT s FROM Saidas s WHERE s.valor = :valor")
    , @NamedQuery(name = "Saidas.findByData", query = "SELECT s FROM Saidas s WHERE s.data = :data")
    , @NamedQuery(name = "Saidas.findByHorario", query = "SELECT s FROM Saidas s WHERE s.horario = :horario")})
public class Saidas implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "codigo")
    private Integer codigo;
    @Basic(optional = false)
    @Column(name = "descricao")
    private String descricao;
    @Column(name = "forma_pagamento")
    private String formaPagamento;
    @Basic(optional = false)
    @Column(name = "valor")
    private float valor;
    @Basic(optional = false)
    @Column(name = "data")
    private String data;
    @Basic(optional = false)
    @Column(name = "horario")
    private String horario;

    public Saidas() {
    }

    public Saidas(Integer codigo) {
        this.codigo = codigo;
    }

    public Saidas(Integer codigo, String descricao, float valor, String data, String horario) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.valor = valor;
        this.data = data;
        this.horario = horario;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        Integer oldCodigo = this.codigo;
        this.codigo = codigo;
        changeSupport.firePropertyChange("codigo", oldCodigo, codigo);
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        String oldDescricao = this.descricao;
        this.descricao = descricao;
        changeSupport.firePropertyChange("descricao", oldDescricao, descricao);
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        String oldFormaPagamento = this.formaPagamento;
        this.formaPagamento = formaPagamento;
        changeSupport.firePropertyChange("formaPagamento", oldFormaPagamento, formaPagamento);
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        float oldValor = this.valor;
        this.valor = valor;
        changeSupport.firePropertyChange("valor", oldValor, valor);
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        String oldData = this.data;
        this.data = data;
        changeSupport.firePropertyChange("data", oldData, data);
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        String oldHorario = this.horario;
        this.horario = horario;
        changeSupport.firePropertyChange("horario", oldHorario, horario);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigo != null ? codigo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Saidas)) {
            return false;
        }
        Saidas other = (Saidas) object;
        if ((this.codigo == null && other.codigo != null) || (this.codigo != null && !this.codigo.equals(other.codigo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "View.Saidas[ codigo=" + codigo + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
